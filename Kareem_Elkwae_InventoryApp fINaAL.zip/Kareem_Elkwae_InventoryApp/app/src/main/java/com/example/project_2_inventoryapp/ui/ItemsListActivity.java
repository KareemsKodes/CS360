package com.example.project_2_inventoryapp.ui;

public class ItemsListActivity {
}
