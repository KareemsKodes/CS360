package com.example.project_2_inventoryapp.ui;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;


public class UsersSQLiteHandler extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;

    private static final String DatabaseName = "UsersData.db";
    public static final String TableName = "UserTable";

    public static final String Column0 = "id";
    public static final String Column1 = "name";
    public static final String Column2 = "phone_number";
    public static final String Column3 = "email";
    public static final String Column4 = "password";

    private static final String CreateUserTable = "Create table if not exist " +
            TableName + " (" +
            Column0 + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            Column1 + " VARCHAR, " +
            Column2 + " VARCHAR, " +
            Column3 + " VARCHAR, " +
            Column4 + " VARCHAR" + ");";

    public UsersSQLiteHandler(Context context) {
        super(context, DatabaseName, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL(CreateUserTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("Drop table if exists " + TableName);
        onCreate(db);
    }

    /**
     * Database CRUD (Create, Read, Update, Delete) Operations
     */

    // Add item to database
    public void createUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Column1, user.getUserName());
        values.put(Column2, user.getUserPhone());
        values.put(Column3, user.getUserEmail());
        values.put(Column4, user.getUserPass());

        db.insert(TableName, null, values);
        db.close();
    }

    // Read item from Database
    public User readUser(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TableName,
                new String[] { Column0, Column1, Column2, Column3, Column4 }, Column0 + " = ?",
                new String[] { String.valueOf(id) }, null, null, null, null);

        if (cursor != null)
            cursor.moveToFirst();

        User user = new User(Integer.parseInt(Objects.requireNonNull(cursor).getString(0)),
                cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4));

        cursor.close();

        return user;
    }

    // Update user in database
    public int updateUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Column1, user.getUserName());
        values.put(Column2, user.getUserPhone());
        values.put(Column3, user.getUserEmail());
        values.put(Column4, user.getUserPass());

        return db.update(TableName, values, Column0 + " = ?", new String[] { String.valueOf(user.getId()) });
    }

    // Delete user from database
    public void deleteItem(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.delete(TableName, Column0 + " = ?", new String[] { String.valueOf(user.getId()) });
        db.close();
    }

    /**
     * Global Database Operations
     */

    // Getting All Users
    public List<User> getAllUsers() {
        List<User> userList = new ArrayList<>();

        // Select All Query
        String selectQuery = "SELECT * FROM " + TableName;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setId(Integer.parseInt(cursor.getString(0)));
                user.setUserName(cursor.getString(1));
                user.setUserPhone(cursor.getString(2));
                user.setUserEmail(cursor.getString(3));
                user.setUserPass(cursor.getString(4));

                userList.add(user);
            } while (cursor.moveToNext());
        }

        cursor.close();

        return userList;
    }

    // Deleting All Users
    public void deleteAllUsers() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(tableName,null,null);
        db.close();
    }

    // Getting Users Count
    public int getUsersCount() {
        String countQuery = "SELECT * FROM " + tableName;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int usersTotal = cursor.getCount();
        cursor.close();

        return usersTotal;
    }
}
}
