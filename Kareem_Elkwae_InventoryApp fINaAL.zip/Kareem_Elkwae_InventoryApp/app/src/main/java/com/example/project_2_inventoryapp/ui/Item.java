package com.example.project_2_inventoryapp.ui;

public class Item {
    int id;
    String email;
    String desc;
    String qty;
    String unit;

    public Item() {
        super();
    }

    public Item(int i, String email, String desc, String qty, String unit) {
        super();
        this.id = i;
        this.email = email;
        this.desc = description;
        this.qty = quantity;
        this.unit = unit;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }
}
