package com.example.project_2_inventoryapp.ui;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.Objects;

public class ItemsSQLiteHandler extends SQLiteOpenHelper {
    private static Final int DatabaseVersion = 1;

    private static final String DatabaseName = "ItemsDatabase";
    private static final String TableName = "ItemsTable";
    private static final String Column0 = "id";
    private static final String Column1 = "email";
    private static final String Column2 = "description";
    private static final String Column3 = "quantity";
    private static final String Column4 = "unit";
    private static final String CreateItemsTable = "Create Table If Not Exists" +
            TableName + " (" +
            Column0 + " INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
            Column1 + " VARCHAR, " +
            Column2 + " VARCHAR, " +
            Column3 + " VARCHAR, " +
            Column4 + " VARCHAR" + ");";

    public ItemsSQLiteHandler(Context context) {
        super(context, DatabaseName, null, DatabaseVersion);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CreateItemsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("Drop Table If Exists" + TableName);
        onCreate(db);
    }

    public void createItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Column1, item.getUserEmail());
        values.put(Column2, item.getDesc());
        values.put(Column3, item.getQty());
        values.put(Column4, item.getUnit());
        db.insert(TableName, null, values);
        db.close();
    }

    public Item readItem(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query( TableName, new String[] {Column0, Column1, Column2, Column3, Column4},new String[] { String.valueOf(id) }, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }

        Item item = new Item(Integer.parseInt(Objects.requireNonNull(cursor).getString(0)), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4));
        cursor.close();
        return item;
    }

    public int updateItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Column1, item.getUserEmail());
        values.put(Column2, item.getDesc());
        values.put(Column3, item.getQty());
        values.put(Column4, item.getUnit());

        return db.update(TableName, null, values, Column0 + " = ?", new String[] { String.valueOf(item.getId()) });

    }

    public void deleteItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TableName, Column0, new String[] { String.valueOf(item.getId()) });
        db.close();
    }
}
