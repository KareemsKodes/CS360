package com.example.project_2_inventoryapp.ui;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupWindow;
import android.widget.Toast;

import com.example.myinventory.R;

public class LoginActivity extends AppCompatActivity {

    Activity activity;
    Button loginButton, registerButton, forgotButton;
    EditText email, password;
    String name, phone, email2, pass;
    Boolean empty;
    PopupWindow popwindow;
    SQLiteDatabase db;
    UsersSQLiteHandler handler;
    String tempPass = "NOT_FOUND" ;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        activity = this;

        //finding my stuff
        loginButton = findViewById(R.id.login);
        registerButton = findViewById(R.id.register);
        forgotButton = findViewById(R.id.forgot);
        email2 = findViewById(R.id.email);
        pass = findViewById(R.id.password);
        handler = new UsersSQLiteHandler(this);

        //login listener
        loginButton.setOnClickListener((view ->  {
            Login();
        }));

        //register listener
        registerButton.setOnClickListener(view ->  {
            Intent intent = new Intent(Login.this, Register.class);
            startActivity(intent);
        });

        //login
        public void Login() {
            String message = CheckEditTextNotEmpty();

            if(!empty) {
                db = handler.getWritableDatabase();

                Cursor cursor = db.query(UsersSQLiteHandler.TableName, null, " " + UsersSQLiteHandler.Column3 + "=?", new String[]{email}, null, null, null);

                while (cursor.moveToNext()) {
                    if(cursor.isFirst()) {
                        cursor.moveToFirst();

                        tempPass = cursor.getString(cursor.getColumnIndex(UsersSQLiteHandler.Column4));
                        name = cursor.getString(cursor.getColumnIndex(UsersSQLiteHandler.Column1));
                        phone = cursor.getString(cursor.getColumnIndex(UsersSQLiteHandler.Column2));

                        cursor.close();
                    }
                }
                handler.close();

                CheckFinalResult();
            }
            else {
                Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
            }
        }

        public void CheckFinalResult() {
            if(tempPass.equalsIgnoreCase((pass)) {
                Toast.makeText(LoginActivity.this, "Success", Toast.LENGTH_SHORT).show();

                Bundle bundle = new bundle();
                bundle.putString("user_name", name);
                bundle.putString("user_email", email);
                bundle.putString("user_phone", phone);

                Intent intent = new Intent(LoginActivity.this, itemListActivity.class);
                intent.putExtras(bundle);
                startActvity(intent);

            }
        }

        public String CheckEditTextNotEmpty() {
            String message = "";

            email2 = email.getText().toString().trim();
            pass = password.getText().toString().trim();

            if (email2.isEmpty()) {
                email.requestFocus();
                empty = true;
                message = "Email field is empty";
            }
            else if (pass.isEmpty()) {
                password.requestFocus();
                empty= true;
                message = "Password field is empty";
            }
            else {
                empty = false;
            }
            return message;
        }

        public void EmptyEditTextAfterDataInsert() {
            email.getText().clear();
            password.getText().clear();
        }


}