package com.example.project_2_inventoryapp.ui;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;

public class RegisterActivity extends AppCompatActivity {
    Button register;
    EditText name, phone, email;
    Boolean empty;
    SQLiteDatabase db;
    UsersSQLiteHandler handler;
    String result = "Not found";

    @Override
    protected void oncreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        name = findViewById(R.id.editText)
    }

}